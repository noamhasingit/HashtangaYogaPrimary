import asanas
from soundstools import  saveText

# asanas.sunSalutationA(5)
# asanas.sunSalutationB(5)
# asanas.padangusthasana(1)
# asanas.padanhastaasana(1)
# asanas.utthitatrikonasanaA(1)
# asanas.utthitatrikonasanaB(1)
# asanas.utthitatrikonasanaC(1)
# asanas.utthitatrikonasanaD(1)
# asanas.utthitaparsvakonasana(1)
# asanas.parivrittaparsvakonasana(1)


asanas.parsvotanasana(4)

asanas.generalAsanaCount(20)